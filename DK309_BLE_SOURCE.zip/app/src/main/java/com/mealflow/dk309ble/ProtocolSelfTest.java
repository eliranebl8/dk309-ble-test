package com.mealflow.dk309ble;
import java.util.*;
/** Executable host-side test of the pure Java protocol encoder/decoder. */
public final class ProtocolSelfTest {
    static void eq(String got, String want) { if (!got.equals(want)) throw new AssertionError("got=" + got + " expected=" + want); }
    static byte[] b(int... values){byte[] out=new byte[values.length];for(int i=0;i<values.length;i++)out[i]=(byte)values[i];return out;}
    public static void main(String[] args) {
        eq(Dk309Protocol.hex(Dk309Protocol.version(false)), "00 71");
        eq(Dk309Protocol.hex(Dk309Protocol.searchOnce(1,false)), "00 62 01");
        eq(Dk309Protocol.hex(Dk309Protocol.searchOnce(2,true)), "03 00 62 02");
        eq(Dk309Protocol.hex(Dk309Protocol.autoSearch(true,1,false)), "00 63 FF 14 01");
        eq(Dk309Protocol.hex(Dk309Protocol.autoSearch(false,1,false)), "00 63 00 14 01");
        Dk309Protocol.Decoder decoder = new Dk309Protocol.Decoder();
        List<Dk309Protocol.Event> events=decoder.consume(b(5,0,0x76,0x90,0,1));
        eq(events.get(0).kind, "BUTTON");
        events=decoder.consume(b(0,0x63,0x90,0,6,4,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF));
        eq(events.get(0).uid,"04AABBCCDDEEFF");
        events=decoder.consume(b(0,0x64,0x90,0,1));
        eq(events.get(0).kind,"AUTO");
        events=decoder.consume(b(1,0x63,0x90,0,6,4,0xAA));
        if (!events.isEmpty()) throw new AssertionError("premature fragmented event");
        events=decoder.consume(b(0xC1,0xBB,0xCC,0xDD,0xEE,0xFF));
        eq(events.get(0).uid,"04AABBCCDDEEFF");
        System.out.println("PASS: DK309 protocol self-tests (7 cases)");
    }
}
