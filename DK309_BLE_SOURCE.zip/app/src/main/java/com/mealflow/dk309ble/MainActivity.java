package com.mealflow.dk309ble;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** DK BLE NFC discovery and opt-in card-search diagnostics. No NFC memory writes. */
public final class MainActivity extends Activity {
    private static final int REQUEST_PERMS = 12;
    private static final UUID SERVICE = uuid16("FFF0");
    private static final UUID RX_DATA = uuid16("FFF2");
    private static final UUID READ_STATUS = uuid16("FFF1");
    private static final UUID CCCD = uuid16("2902");
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> discovered = new LinkedHashMap<>();
    private final Map<String, String> deviceNames = new LinkedHashMap<>();
    private final StringBuilder fullLog = new StringBuilder();
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic statusChar;
    private BluetoothGattCharacteristic txChar;
    private final Dk309Protocol.Decoder decoder = new Dk309Protocol.Decoder();
    private CheckBox lengthPrefix;
    private boolean notifyReady;
    private boolean autoMode;
    private long lastWriteMs;
    private String lastUid = "";
    private long lastUidAt;

    private ScanCallback scanCallback;
    private boolean scanning;
    private TextView state, logView;
    private Button chooseButton;
    private ScrollView logScroller;
    private int packetCount = 0;

    private static UUID uuid16(String hex) {
        return UUID.fromString("0000" + hex + "-0000-1000-8000-00805f9b34fb");
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(22, 44, 65));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(20), dp(14), dp(12));
        root.setBackgroundColor(Color.rgb(247, 249, 252));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView heading = new TextView(this);
        heading.setText("DK309 · בדיקת Bluetooth");
        heading.setTextSize(23);
        heading.setTextColor(Color.rgb(26, 51, 76));
        heading.setGravity(Gravity.RIGHT);
        root.addView(heading);
        TextView helper = new TextView(this);
        helper.setText("BLE בלבד · גרסת בדיקה v0.2 · פקודות חיפוש ממימוש DK ציבורי");
        helper.setTextSize(12);
        helper.setTextColor(Color.GRAY);
        root.addView(helper);
        state = new TextView(this);
        state.setText("ממתין לבדיקת הרשאות");
        state.setTextColor(Color.rgb(10, 88, 95));
        state.setPadding(0, dp(14), 0, dp(8));
        root.addView(state);

        addPair(root, "1. חפש BLE_NFC", v -> startScan(), "2. התחבר", v -> chooseDevice());
        addPair(root, "קרא FFF1", v -> readFff1(), "בדוק גרסה (0x71)", v -> sendVersion());
        addPair(root, "חיפוש חד־פעמי P3", v -> scanOnce(1), "חיפוש חד־פעמי P4", v -> scanOnce(2));
        addPair(root, "הפעל סריקה P3", v -> startAuto(1), "הפסק סריקה", v -> stopAuto());
        lengthPrefix = new CheckBox(this);
        lengthPrefix.setText("מצב ניסוי: הוסף בייט אורך לפני הפקודה (רק אם אין תגובה)");
        lengthPrefix.setTextSize(12);
        lengthPrefix.setChecked(false);
        root.addView(lengthPrefix);
        addPair(root, "נתק", v -> disconnect(), "שתף יומן", v -> share());
        addButton(root, "נקה יומן", v -> { fullLog.setLength(0); logView.setText(""); packetCount = 0; });
        logScroller = new ScrollView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1);
        lp.topMargin = dp(12);
        root.addView(logScroller, lp);
        logView = new TextView(this);
        logView.setTextSize(12);
        logView.setTextIsSelectable(true);
        logView.setTextColor(Color.rgb(34, 45, 52));
        logView.setBackgroundColor(Color.WHITE);
        logView.setPadding(dp(8), dp(8), dp(8), dp(8));
        logView.setTextDirection(View.TEXT_DIRECTION_LTR);
        logScroller.addView(logView);
        setContentView(root);
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        note("פתח/י את nRF Connect ונתק/י ממנו את הקורא לפני שמתחברים כאן.");
        note("v0.2: FFF0 / FFF1 read / FFF2 notify+write; סריקת NFC יזומה לפי קוד SDK ציבורי.");
        note("התחל בבדיקת גרסה 0x71, ואז שים כרטיס על הקורא והפעל חיפוש P3.");
        requestPermissionsIfNeeded();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private Button addButton(LinearLayout root, String text, View.OnClickListener click) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(45));
        lp.bottomMargin = dp(2);
        root.addView(btn, lp);
        return btn;
    }
    private void addPair(LinearLayout root, String one, View.OnClickListener first,
                         String two, View.OnClickListener second) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row, new LinearLayout.LayoutParams(-1, dp(49)));
        Button left = new Button(this);
        left.setText(one); left.setAllCaps(false); left.setTextSize(11);
        left.setOnClickListener(first);
        row.addView(left, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button right = new Button(this);
        right.setText(two); right.setAllCaps(false); right.setTextSize(11);
        right.setOnClickListener(second);
        row.addView(right, new LinearLayout.LayoutParams(0, dp(48), 1));
    }
    private void note(String message) {
        runOnUiThread(() -> {
            String when = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
            String line = "[" + when + "] " + message + "\n";
            fullLog.append(line);
            logView.append(line);
            if (logView.getText().length() > 20000) logView.setText(fullLog.substring(Math.max(0, fullLog.length() - 15000)));
            logScroller.post(() -> logScroller.fullScroll(View.FOCUS_DOWN));
        });
    }
    private void setState(String value) { runOnUiThread(() -> state.setText(value)); }
    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestPermissionsIfNeeded() {
        if (hasPermissions()) { setState("הרשאות BLE מאושרות"); return; }
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMS);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMS);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMS) setState(hasPermissions() ? "הרשאות BLE מאושרות" : "יש לאשר הרשאות 'מכשירים בקרבת מקום'");
    }

    private void startScan() {
        if (!hasPermissions()) { requestPermissionsIfNeeded(); return; }
        if (adapter == null || !adapter.isEnabled()) {
            note("יש להפעיל Bluetooth בהגדרות הטאבלט."); return;
        }
        stopScan();
        discovered.clear(); deviceNames.clear();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { note("BLE scanner unavailable"); return; }
        scanCallback = new ScanCallback() {
            @Override public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                String address = device.getAddress();
                String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
                try { if (TextUtils.isEmpty(name)) name = device.getName(); } catch (SecurityException ignored) { }
                if (TextUtils.isEmpty(name)) name = "[ללא שם]";
                if (!discovered.containsKey(address)) {
                    discovered.put(address, device);
                    deviceNames.put(address, name + "  (RSSI " + result.getRssi() + ")");
                    note("FOUND " + name + "   " + address + "   RSSI=" + result.getRssi());
                    setState("נמצאו " + discovered.size() + " התקנים. לחץ 'בחר קורא'.");
                }
            }
            @Override public void onScanFailed(int errorCode) { note("SCAN FAILED " + errorCode); setState("שגיאת סריקה " + errorCode); }
        };
        try {
            scanner.startScan(scanCallback);
            scanning = true;
            setState("סורק Bluetooth Low Energy...");
            note("Scan started (12 seconds)");
            handler.postDelayed(this::stopScan, 12000);
        } catch (SecurityException ex) { note("Permission denied: " + ex.getMessage()); }
    }
    private void stopScan() {
        if (scanning && scanner != null && scanCallback != null) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
            scanning = false;
            note("Scan stopped. Found " + discovered.size() + " devices.");
        }
    }
    private void chooseDevice() {
        if (discovered.isEmpty()) { note("לא נמצאו קוראים. חפש קודם."); return; }
        ArrayList<String> keys = new ArrayList<>(discovered.keySet());
        String[] items = new String[keys.size()];
        for (int i = 0; i < keys.size(); i++) items[i] = deviceNames.get(keys.get(i)) + "\n" + keys.get(i);
        new AlertDialog.Builder(this).setTitle("בחר BLE_NFC").setItems(items, (d, which) -> connect(discovered.get(keys.get(which)))).setNegativeButton("ביטול", null).show();
    }
    private void connect(BluetoothDevice device) {
        stopScan(); disconnect();
        try {
            note("Connecting to " + device.getAddress());
            setState("מתחבר...");
            gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE);
        } catch (SecurityException ex) { note("Cannot connect: " + ex.getMessage()); }
    }
    private final BluetoothGattCallback callback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int newState) {
            note("GATT state=" + newState + " status=" + status);
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                setState("מחובר. מגלה שירותים...");
                try { g.discoverServices(); } catch (SecurityException ex) { note("discoverServices denied"); }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                setState("מנותק");
                statusChar = null; txChar = null; notifyReady = false; autoMode = false;
                try { g.close(); } catch (Exception ignored) { }
                if (gatt == g) gatt = null;
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            note("Services discovered: status=" + status);
            if (status != BluetoothGatt.GATT_SUCCESS) return;
            for (BluetoothGattService s : g.getServices()) {
                note("Service " + s.getUuid());
                for (BluetoothGattCharacteristic c : s.getCharacteristics())
                    note("  Characteristic " + c.getUuid() + " props=0x" + Integer.toHexString(c.getProperties()));
            }
            BluetoothGattService svc = g.getService(SERVICE);
            if (svc == null) { setState("FFF0 לא נמצא"); note("Missing FFF0"); return; }
            statusChar = svc.getCharacteristic(READ_STATUS);
            BluetoothGattCharacteristic rx = svc.getCharacteristic(RX_DATA);
            txChar = rx; notifyReady = false; autoMode = false;
            if (rx == null) { note("FFF2 not found"); return; }
            boolean success;
            try { success = g.setCharacteristicNotification(rx, true); }
            catch (SecurityException ex) { note("Cannot enable notifications: " + ex.getMessage()); return; }
            note("setCharacteristicNotification(FFF2)=" + success);
            BluetoothGattDescriptor descriptor = rx.getDescriptor(CCCD);
            if (descriptor == null) { note("CCCD 2902 missing"); return; }
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            try {
                boolean writing = g.writeDescriptor(descriptor);
                note("CCCD subscription requested=" + writing);
            } catch (SecurityException ex) { note("CCCD permission error"); }
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor d, int status) {
            note("CCCD write result=" + status + " (0=success)");
            if (status == BluetoothGatt.GATT_SUCCESS) {
                notifyReady = true;
                setState("מחובר ומאזין FFF2 — מוכן לפקודת סריקה");
                note("READY: write 0x71 (version) or search card 0x62 / 0x63");
            }
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c) {
            received(c.getUuid(), c.getValue());
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value) {
            received(c.getUuid(), value);
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, int status) {
            note("READ " + c.getUuid() + " status=" + status + " HEX=" + hex(c.getValue()));
        }
        @Override public void onCharacteristicRead(BluetoothGatt g, BluetoothGattCharacteristic c, byte[] value, int status) {
            note("READ " + c.getUuid() + " status=" + status + " HEX=" + hex(value));
        }
    };
    private void received(UUID characteristic, byte[] value) {
        packetCount++;
        note("NOTIFY #" + packetCount + " " + characteristic + " length=" + (value == null ? 0 : value.length)
                + " HEX=" + hex(value) + " ASCII=" + ascii(value));
        for (Dk309Protocol.Event event : decoder.consume(value)) {
            note("DECODE [" + event.kind + "] " + event.message);
            if (event.uid != null) {
                long now = SystemClock.elapsedRealtime();
                if (!event.uid.equals(lastUid) || now - lastUidAt > 1500) {
                    note("***** UID " + event.uid + " *****");
                    setState("כרטיס זוהה! UID: " + event.uid);
                    lastUid = event.uid; lastUidAt = now;
                }
            } else if ("AUTO".equals(event.kind) && event.status1 != 0x90) {
                autoMode = false;
            }
        }
    }
    private void sendVersion() {
        sendCommand(Dk309Protocol.version(lengthPrefix.isChecked()), "GET_VERSION (0x71)");
    }
    private void scanOnce(int layer) {
        note("יש להצמיד כרטיס למרכז הקורא לפני הפעלת חיפוש חד־פעמי");
        sendCommand(Dk309Protocol.searchOnce(layer, lengthPrefix.isChecked()), "SEARCH_ONCE P" + layer);
    }
    private void startAuto(int layer) {
        if (sendCommand(Dk309Protocol.autoSearch(true, layer, lengthPrefix.isChecked()), "START_AUTO P" + layer)) {
            autoMode = true;
            note("AUTO SEARCH requested, 200ms interval; check for reply 0x64");
        }
    }
    private void stopAuto() {
        if (sendCommand(Dk309Protocol.autoSearch(false, 1, lengthPrefix.isChecked()), "STOP_AUTO")) {
            autoMode = false;
        }
    }
    private boolean sendCommand(byte[] command, String name) {
        if (gatt == null || txChar == null || !notifyReady) {
            note("אין חיבור מוכן. המתן ל-CCCD write result=0"); return false;
        }
        int props = txChar.getProperties();
        if ((props & (BluetoothGattCharacteristic.PROPERTY_WRITE | BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) == 0) {
            note("FFF2 does not support write"); return false;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastWriteMs < 300) { note("המתן רגע בין פקודות"); return false; }
        lastWriteMs = now;
        int type = (props & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
                ? BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                : BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                int result = gatt.writeCharacteristic(txChar, command, type);
                note("TX " + name + " HEX=" + hex(command) + " apiResult=" + result);
                return result == BluetoothStatusCodes.SUCCESS;
            }
            txChar.setWriteType(type);
            txChar.setValue(command);
            boolean sent = gatt.writeCharacteristic(txChar);
            note("TX " + name + " HEX=" + hex(command) + " submitted=" + sent);
            return sent;
        } catch (SecurityException | IllegalArgumentException e) {
            note("TX ERROR " + e.toString()); return false;
        }
    }
    private static String hex(byte[] data) {
        if (data == null) return "[null]";
        StringBuilder s = new StringBuilder();
        for (byte b : data) s.append(String.format(Locale.US, "%02X ", b & 255));
        return s.toString().trim();
    }
    private static String ascii(byte[] data) {
        if (data == null) return "";
        StringBuilder s = new StringBuilder();
        for (byte b : data) { int n = b & 255; s.append(n >= 32 && n < 127 ? (char)n : '.'); }
        return s.toString();
    }
    private void readFff1() {
        if (gatt == null || statusChar == null) { note("Connect first; FFF1 unavailable"); return; }
        if ((statusChar.getProperties() & BluetoothGattCharacteristic.PROPERTY_READ) == 0) {
            note("FFF1 is not readable"); return;
        }
        try { note("Read FFF1 requested=" + gatt.readCharacteristic(statusChar)); }
        catch (SecurityException ex) { note("Read permission denied"); }
    }
    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "DK309 BLE diagnostic");
        i.putExtra(Intent.EXTRA_TEXT, fullLog.toString());
        startActivity(Intent.createChooser(i, "שתף יומן בדיקה"));
    }
    private void disconnect() {
        if (gatt != null) {
            if (autoMode && notifyReady) {
                // Best effort stop. For predictable radio shutdown, user should press Stop first.
                note("הסריקה הייתה פעילה — כדאי ללחוץ הפסק לפני ניתוק");
            }
            BluetoothGatt old = gatt; gatt = null; statusChar = null; txChar = null;
            notifyReady = false; autoMode = false;
            try { old.disconnect(); old.close(); } catch (SecurityException ignored) { }
            setState("מנותק"); note("Disconnected by user");
        }
    }
    @Override protected void onDestroy() { stopScan(); disconnect(); super.onDestroy(); }
}
