package com.mealflow.dk309ble;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Minimal BLE NFC reader commands modeled after the public BLE_NFC DK command protocol.
 * This is diagnostic code and has NOT been validated against DK309 firmware.
 * It never writes to NFC card memory.
 */
public final class Dk309Protocol {
    private Dk309Protocol() { }
    public static final int SEARCH_ONCE = 0x62;
    public static final int AUTO_SEARCH = 0x63;
    public static final int GET_VERSION = 0x71;
    private static final int SW_OK = 0x90;

    public static byte[] version(boolean lengthPrefix) { return command(GET_VERSION, lengthPrefix); }
    public static byte[] searchOnce(int layer, boolean lengthPrefix) {
        if (layer != 1 && layer != 2) throw new IllegalArgumentException("layer must be 1 or 2");
        return command(SEARCH_ONCE, lengthPrefix, layer);
    }
    public static byte[] autoSearch(boolean start, int layer, boolean lengthPrefix) {
        if (layer != 1 && layer != 2) throw new IllegalArgumentException("layer must be 1 or 2");
        // DK SDK interval is in units of 10 milliseconds: 0x14 => 200ms.
        return command(AUTO_SEARCH, lengthPrefix, start ? 0xFF : 0x00, 0x14, layer);
    }
    private static byte[] command(int cmd, boolean lengthPrefix, int... params) {
        byte[] frame = new byte[2 + params.length];
        frame[0] = 0; // initial frame, zero continuation frames
        frame[1] = (byte)cmd;
        for (int i = 0; i < params.length; i++) frame[i + 2] = (byte)params[i];
        if (!lengthPrefix) return frame;
        byte[] wrapped = new byte[frame.length + 1];
        wrapped[0] = (byte)frame.length;
        System.arraycopy(frame, 0, wrapped, 1, frame.length);
        return wrapped;
    }

    public static String hex(byte[] data) {
        if (data == null) return "(null)";
        StringBuilder b = new StringBuilder();
        for (byte v : data) {
            if (b.length() > 0) b.append(' ');
            b.append(String.format(Locale.US, "%02X", v & 0xFF));
        }
        return b.toString();
    }

    public static final class Event {
        public final int responseCommand, status1, status2;
        public final byte[] payload;
        public final String kind, message, uid;
        Event(int cmd, int sw1, int sw2, byte[] payload, String kind, String message, String uid) {
            this.responseCommand = cmd; this.status1 = sw1; this.status2 = sw2;
            this.payload = payload; this.kind = kind; this.message = message; this.uid = uid;
        }
    }

    /** Decode 00 CMD SW1 SW2 PAYLOAD or length-prefixed BLE variants. */
    public static final class Decoder {
        private final ByteArrayOutputStream data = new ByteArrayOutputStream();
        private int expectedFollow = -1;
        private int lastFollow = 0;
        private int pendingCommand, pendingSw1, pendingSw2;

        public synchronized List<Event> consume(byte[] raw) {
            ArrayList<Event> events = new ArrayList<>();
            if (raw == null || raw.length == 0) return events;
            byte[] f = raw;
            // The user's FFF2 button notification was: 05 00 76 90 00 01.
            // 05 is plausibly a one-byte length prefix; actual SDK frame is 00 76 90 00 01.
            if (f.length >= 5 && (f[0] & 0xff) == f.length - 1 && (f[1] & 0xC0) == 0) {
                f = Arrays.copyOfRange(f, 1, f.length);
            }
            int kind = f[0] & 0xC0;
            if (kind == 0 && f.length >= 4) {
                expectedFollow = f[0] & 0x3F;
                lastFollow = 0;
                pendingCommand = f[1] & 0xFF;
                pendingSw1 = f[2] & 0xFF;
                pendingSw2 = f[3] & 0xFF;
                data.reset();
                data.write(f, 4, f.length - 4);
                if (expectedFollow == 0) {
                    events.add(classify(pendingCommand, pendingSw1, pendingSw2, data.toByteArray()));
                    expectedFollow = -1;
                }
            } else if (kind == 0xC0 && expectedFollow > 0 && f.length >= 2) {
                int frameNo = f[0] & 0x3F;
                if (frameNo != lastFollow + 1 || data.size() + f.length > 1024) {
                    events.add(new Event(-1, 0, 0, raw, "WARN", "שגיאת סדר מסגרות BLE", null));
                    expectedFollow = -1;
                } else {
                    data.write(f, 1, f.length - 1);
                    lastFollow = frameNo;
                    if (frameNo == expectedFollow) {
                        events.add(classify(pendingCommand, pendingSw1, pendingSw2, data.toByteArray()));
                        expectedFollow = -1;
                    }
                }
            } else {
                events.add(new Event(-1, 0, 0, raw, "RAW", "תשובה שלא פוענחה; נשלחה ליומן", null));
            }
            return events;
        }
    }

    private static Event classify(int cmd, int sw1, int sw2, byte[] payload) {
        boolean ok = sw1 == SW_OK && sw2 == 0;
        String info = "response 0x" + String.format(Locale.US, "%02X", cmd)
                + " status=" + String.format(Locale.US, "%02X %02X", sw1, sw2);
        if (cmd == 0x76) { // request 0x75 button, response opcode incremented by 1
            String press = payload.length > 0 ? ((payload[0]&0xff) == 1 ? "לחיצה קצרה" : "לחיצה/לחיצה ארוכה " + (payload[0]&0xff)) : "ללא נתונים";
            return new Event(cmd, sw1, sw2, payload, "BUTTON", "כפתור הקורא: " + press, null);
        }
        if (cmd == 0x72) {
            return new Event(cmd, sw1, sw2, payload, "VERSION", "תגובת גרסה: " + info + " data=" + hex(payload), null);
        }
        if (cmd == 0x64) {
            return new Event(cmd, sw1, sw2, payload, "AUTO", "תשובת מצב סריקה אוטומטית: " + (ok ? "אושרה" : "נדחתה") + "; " + info, null);
        }
        if (cmd == 0x63) {
            if (!ok) return new Event(cmd, sw1, sw2, payload, "CARD", "חיפוש כרטיס נכשל: " + info, null);
            if (payload.length < 2) return new Event(cmd, sw1, sw2, payload, "CARD", "תשובת חיפוש ללא UID: " + hex(payload), null);
            int cardType = payload[0] & 0xFF;
            int uidLength;
            if (cardType == 6 || cardType == 7) uidLength = 7; // NTAG/Ultralight or DESFire
            else if (cardType == 5) uidLength = 8; // ISO15693
            else if (cardType == 1 || cardType == 4) uidLength = 4; // 14443A CPU / Mifare
            else return new Event(cmd, sw1, sw2, payload, "CARD", "סוג כרטיס חדש " + cardType + " · HEX=" + hex(payload), null);
            if (payload.length < 1 + uidLength) return new Event(cmd, sw1, sw2, payload, "CARD", "תשובת כרטיס חלקית: " + hex(payload), null);
            byte[] bytes = Arrays.copyOfRange(payload, 1, 1 + uidLength);
            String uid = hex(bytes).replace(" ", "");
            return new Event(cmd, sw1, sw2, payload, "CARD_UID", "כרטיס זוהה! TYPE=" + cardType + " UID=" + uid, uid);
        }
        return new Event(cmd, sw1, sw2, payload, "RESPONSE", info + " data=" + hex(payload), null);
    }
}
